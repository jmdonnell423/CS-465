import { HttpClient } from '@angular/common/http'; // Import HttpClient
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class AuthenticationService {
  private loggedInSubject = new BehaviorSubject<boolean>(this.isLoggedIn());
  public loggedIn$: Observable<boolean> = this.loggedInSubject.asObservable();
  private apiUrl = 'https://your-api-url/login'; // Replace with your backend API URL

  constructor(private http: HttpClient) {} // Inject HttpClient

  public login(credentials: { email: string; password: string }): Observable<any> {
    return this.http.post<{ token: string }>(this.apiUrl, credentials).pipe(
      map((response) => {
        this.saveToken(response.token); // Save the token to localStorage
        this.loggedInSubject.next(true); // Update login state
        return response;
      })
    );
  }

  public saveToken(token: string): void {
    localStorage.setItem('travlr-token', token); // Store the token
  }

  public logout(): void {
    localStorage.removeItem('travlr-token'); // Remove the token
    this.loggedInSubject.next(false); // Update login state
  }

  public isLoggedIn(): boolean {
    return !!localStorage.getItem('travlr-token'); // Check if token exists
  }
}








