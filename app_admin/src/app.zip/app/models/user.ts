export interface User {
    email: string;
    name?: string; // Optional field
    password: string;
  }
  
  
  
