import { Services } from './services';

describe('Services', () => {
  it('should create an instance', () => {
    expect(new Services()).toBeTruthy();
  });
});
