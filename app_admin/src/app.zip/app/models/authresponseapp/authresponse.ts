export class AuthResponse {
    token: string = ''; // Default initialization
  }
  
  